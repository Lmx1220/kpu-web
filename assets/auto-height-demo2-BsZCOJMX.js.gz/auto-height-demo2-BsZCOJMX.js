import{_ as o}from"./auto-height-demo2.vue_vue_type_script_setup_true_lang-PfwoK8G8.js";import"./bootstrap-BssOdyNs.js";import"./index-CI4shd_A.js";export{o as default};
