import{aM as c}from"./index-putfknEa.js";/**
 * @license lucide-vue-next v0.471.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=c("CheckIcon",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{o as C};
