import{_ as o}from"./auto-height-demo2.vue_vue_type_script_setup_true_lang-BZEKV4SK.js";import"./bootstrap-CFLGDgEx.js";import"./index-CWw-wBac.js";export{o as default};
