import{_ as o}from"./switch.vue_vue_type_script_setup_true_lang-CWLNjrT1.js";import"./bootstrap-aYN_ym_b.js";import"./index-CbsWY-kb.js";export{o as default};
