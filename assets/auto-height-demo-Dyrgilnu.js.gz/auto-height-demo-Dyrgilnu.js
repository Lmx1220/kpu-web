import{_ as o}from"./auto-height-demo.vue_vue_type_script_setup_true_lang-BVmBLQ1s.js";import"./bootstrap-BssOdyNs.js";import"./index-CI4shd_A.js";export{o as default};
