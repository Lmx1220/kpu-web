import{_ as o}from"./select.vue_vue_type_script_setup_true_lang-B5NLrMcs.js";import"./bootstrap-BssOdyNs.js";import"./index-CI4shd_A.js";export{o as default};
