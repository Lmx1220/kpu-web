import{d as o,a,D as t,f as n,o as r}from"./index-D6ceO_Rb.js";const d=o({name:"Reload",__name:"reload",setup(s){const e=a();return t(()=>{e.go(-1)}),(c,u)=>(r(),n("div"))}});export{d as default};
