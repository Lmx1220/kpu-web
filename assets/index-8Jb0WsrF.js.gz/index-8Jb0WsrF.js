import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-D4o8hdWv.js";import"./index-Db9foyL6.js";export{m as default};
