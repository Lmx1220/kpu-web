import{_ as o}from"./select.vue_vue_type_script_setup_true_lang-fUyiu32i.js";import"./bootstrap-BlzOfB9o.js";import"./index-DERO0-td.js";export{o as default};
