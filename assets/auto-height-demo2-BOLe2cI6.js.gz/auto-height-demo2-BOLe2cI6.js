import{_ as o}from"./auto-height-demo2.vue_vue_type_script_setup_true_lang-Cb3cmkd_.js";import"./bootstrap-CKvMAU9X.js";import"./index-DW2EscPo.js";export{o as default};
