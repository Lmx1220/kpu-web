import{_ as o}from"./rate.vue_vue_type_script_setup_true_lang-DGPW0JPo.js";import"./bootstrap-CKvMAU9X.js";import"./index-DW2EscPo.js";export{o as default};
