import{_ as o}from"./inputnumber.vue_vue_type_script_setup_true_lang-jwxKrIj3.js";import"./bootstrap-aYN_ym_b.js";import"./index-CbsWY-kb.js";export{o as default};
