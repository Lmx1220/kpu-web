import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BR67_aZQ.js";import"./index-2if5aP_c.js";import"./use-resolve-button-type-gHTIM70e.js";export{o as default};
