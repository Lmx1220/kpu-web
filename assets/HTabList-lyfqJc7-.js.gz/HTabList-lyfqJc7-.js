import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-b-H45Vfq.js";import"./index-B3Xk5Nw4.js";import"./use-resolve-button-type-Cpzb3W9k.js";export{o as default};
