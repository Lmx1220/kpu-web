import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-YXp4v4n2.js";import"./index-BVRkYg_n.js";import"./logo-D-CqFC5K.js";export{o as default};
