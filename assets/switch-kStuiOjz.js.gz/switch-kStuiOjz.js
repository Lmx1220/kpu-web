import{_ as o}from"./switch.vue_vue_type_script_setup_true_lang-D4oSEEiG.js";import"./bootstrap-BlzOfB9o.js";import"./index-DERO0-td.js";export{o as default};
