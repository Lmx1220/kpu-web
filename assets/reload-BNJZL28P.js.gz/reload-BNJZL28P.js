import{d as o,a,l as t,c as n,o as r}from"./index-CR1TrdTw.js";const d=o({name:"Reload",__name:"reload",setup(s){const e=a();return t(()=>{e.go(-1)}),(c,u)=>(r(),n("div"))}});export{d as default};
