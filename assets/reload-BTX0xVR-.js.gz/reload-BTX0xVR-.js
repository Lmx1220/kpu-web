import{d as o,a,m as t,c as n,o as r}from"./index-BSkZKgnl.js";const _=o({name:"Reload",__name:"reload",setup(s){const e=a();return t(()=>{e.go(-1)}),(c,m)=>(r(),n("div"))}});export{_ as default};
