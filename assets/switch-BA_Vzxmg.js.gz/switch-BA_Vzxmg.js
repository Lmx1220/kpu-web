import{_ as o}from"./switch.vue_vue_type_script_setup_true_lang-Djj3vulJ.js";import"./bootstrap-BssOdyNs.js";import"./index-CI4shd_A.js";export{o as default};
