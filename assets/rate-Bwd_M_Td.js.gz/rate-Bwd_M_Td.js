import{_ as o}from"./rate.vue_vue_type_script_setup_true_lang-bV4XW_4z.js";import"./bootstrap-BlzOfB9o.js";import"./index-DERO0-td.js";export{o as default};
