import{_ as o}from"./rate.vue_vue_type_script_setup_true_lang-CK5AKOfT.js";import"./bootstrap-aYN_ym_b.js";import"./index-CbsWY-kb.js";export{o as default};
