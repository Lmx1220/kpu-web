import{_ as o}from"./select.vue_vue_type_script_setup_true_lang-BtFlzj5J.js";import"./bootstrap-CFLGDgEx.js";import"./index-CWw-wBac.js";export{o as default};
