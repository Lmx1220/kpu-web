import{_ as o}from"./auto-height-demo2.vue_vue_type_script_setup_true_lang-DWVAAcRn.js";import"./bootstrap-BlzOfB9o.js";import"./index-DERO0-td.js";export{o as default};
