import{_ as o}from"./input.vue_vue_type_script_setup_true_lang-BDVZyYMp.js";import"./bootstrap-CKvMAU9X.js";import"./index-DW2EscPo.js";export{o as default};
