import{_ as o}from"./rate.vue_vue_type_script_setup_true_lang-C3iDueCl.js";import"./bootstrap-CFLGDgEx.js";import"./index-CWw-wBac.js";export{o as default};
