import{_ as o}from"./rate.vue_vue_type_script_setup_true_lang-B2iiQ3ui.js";import"./bootstrap-BssOdyNs.js";import"./index-CI4shd_A.js";export{o as default};
