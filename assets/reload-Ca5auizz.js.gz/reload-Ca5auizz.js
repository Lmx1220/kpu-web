import{d as o,a,B as t,f as n,o as r}from"./index-BVRkYg_n.js";const d=o({name:"Reload",__name:"reload",setup(s){const e=a();return t(()=>{e.go(-1)}),(c,u)=>(r(),n("div"))}});export{d as default};
