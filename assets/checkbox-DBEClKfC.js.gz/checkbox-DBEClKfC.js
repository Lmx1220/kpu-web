import{_ as o}from"./checkbox.vue_vue_type_script_setup_true_lang-k_nhScx2.js";import"./bootstrap-BssOdyNs.js";import"./index-CI4shd_A.js";export{o as default};
