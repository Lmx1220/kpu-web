import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DSRnFyRP.js";import"./index-BESVIvMK.js";import"./use-resolve-button-type-BoW_5kOg.js";export{o as default};
